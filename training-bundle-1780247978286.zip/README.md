# Training bundle — Toitures VB roof_sections v1.6

Snapshot exporté le 2026-05-31T17:19:38.262Z.

- **1 datasets** au total
- Splits : 1 train · 0 val · 0 test (70/15/15 ± hash deterministic)
- Schema version : training_lab/1.0.0

## Structure

```
takeoffs.zip
├── README.md                       ← ce fichier
├── manifest.json                   ← liste des datasets + splits + correction_weights
├── metadata.json                   ← back-compat legacy (ignorer si tu es nouveau)
└── takeoffs/
    └── <reference>/                ← un dossier par dataset
        ├── raw_image.jpg           ← image satellite 1280×1280 (Google Static Maps satellite)
        ├── annotated_image.jpg     ← optionnel (présent pour les datasets venus de soumissions)
        ├── debug_overlay.jpg       ← image satellite hybrid (avec labels) — optionnel
        ├── takeoff.json            ← metadata du dataset (voir ci-dessous)
        ├── roof_model.json         ← VÉRITÉ HUMAINE — TARGET D'ENTRAÎNEMENT
        ├── roof_sections_v16.json  ← prédiction IA brute (input baseline)
        ├── diff.json               ← signal de correction (hard-negative mining)
        ├── calibration_report.json ← métadonnées calibration (mostly null pour Map Mode)
        ├── notes.md                ← notes humaines libres
        └── validation_report.json  ← état des gates de validation
```

## Système de coordonnées

**Toutes les coordonnées pixels** dans les JSON (`roof_model.sections[].pts`,
`roof_sections_v16.sections[].points`, `building_polygon_px`) sont en :

- **Origine** : top-left de l'image
- **X** : vers la droite (0 → width)
- **Y** : vers le bas (0 → height)
- **Image standard** : 1280 × 1280 pixels (vérifie `image_meta.width/height` dans `takeoff.json`)

C'est le système Google Static Maps standard (= cv2 / PIL standard).

## Loader Python minimal (RECOMMANDÉ — utilise takeoff.json comme source unique)

```python
import json, os
from pathlib import Path
from PIL import Image

def load_dataset(folder: Path):
    with open(folder / 'takeoff.json') as f:
        meta = json.load(f)
    # IMPORTANT : utilise takeoff.json['roof_model_polygons_px'] comme source
    # canonique des polygones target. C'est une normalisation [[x,y], ...] des
    # polygones humains, alignée sur le même format que roof_sections_v16.
    target_polygons = meta['roof_model_polygons_px']  # list of list of [x, y]
    # Image satellite — taille connue via image_meta (typiquement 1280x1280)
    image = Image.open(folder / meta['image_meta']['image_filename'])
    # Optionnel : baseline IA brute (sections du pipeline v1.6 conservative)
    v16_path = folder / 'roof_sections_v16.json'
    baseline_polygons = None
    if v16_path.exists():
        v16 = json.load(open(v16_path))
        # Filtre uniquement les sections 'kept' (selection_status est la SEULE
        # vérité d'activation dans v1.6, cf. fromRoofSectionsV16.ts).
        baseline_polygons = [
            s['points'] for s in v16.get('sections', [])
            if s.get('selection_status') == 'kept'
        ]
    # Optionnel : pondération loss pour hard-negative mining
    diff_path = folder / 'diff.json'
    loss_weight = 0.0
    if diff_path.exists():
        diff = json.load(open(diff_path))
        loss_weight = float(diff.get('correction_weight', 0))  # 0 = facile, 1 = redraw total
    # Optionnel : focal area = bounding box du bâtiment en image-px (déjà projeté)
    building_px = meta.get('building_polygon_px')  # list of [x, y] ou None
    return image, target_polygons, baseline_polygons, loss_weight, building_px

# Itération sur le split train
with open('manifest.json') as f:
    manifest = json.load(f)
assert manifest['schema_version'] == 'training_lab/1.0.0', 'schema bump — verifier le code'
# Skip les datasets dont l'image n'a pas pu être fetchée (URL Google stale)
failed_refs = {f['reference'] for f in manifest.get('image_fetch_failures', [])}
train_refs = [d['reference'] for d in manifest['datasets']
              if d['split'] == 'train' and d['reference'] not in failed_refs]
for ref in train_refs:
    img, polys, base, w, bldg = load_dataset(Path('takeoffs') / ref)
    # ... ton training loop ici ...
```

## ⚠️ Format des polygones — IMPORTANT

Trois sources de polygones cohabitent dans le bundle, avec **trois formats légèrement différents** :

| Source | Champ | Format | Recommandation |
|---|---|---|---|
| **takeoff.json** (NEW) | `roof_model_polygons_px` | `[[x,y], …]` | **À UTILISER comme target d'entraînement** |
| **takeoff.json** (NEW) | `building_polygon_px` | `[[x,y], …]` | focal area / bounding box |
| roof_model.json | `sections[i].pts` | `[{x:number, y:number}, …]` (objets) | brut — préférer la version normalisée ci-dessus |
| roof_sections_v16.json | `sections[i].points` | `[[x,y], …]` | OK pour baseline (filtrer selection_status='kept') |

**Tous en pixels image, origine top-left, Y vers le bas.** Image typique 1280×1280 (vérifie `takeoff.json['image_meta']['width/height']`).

## Champs roof_model.json à IGNORER pour le training 2D

Le fichier `roof_model.json` est un dump complet du tracer. Pour de l'entraînement 2D polygone, **seul `sections` compte**. Tu peux ignorer en safe :

- `valleys` : noues 3D calculées par le moteur (entre sections adjacentes)
- `planes` : équations des plans 3D `a·x + b·y + c`
- `accessories` : objets posés sur le toit (Maximum 301, etc.)
- `georef`, `mvp_source_snapshot`, `calibration`, `review_state` : métadonnées

→ La normalisation `takeoff.json['roof_model_polygons_px']` extrait DÉJÀ seulement `sections.pts` pour toi.

## Sémantique du `correction_weight` (hard-negative mining)

- `0.0` : l'humain n'a quasi rien corrigé — l'IA était déjà bonne sur ce cas. **Loss weight x1**.
- `0.5` : correction moyenne. **Loss weight x1.5 ou x2** typique.
- `1.0` : l'humain a tout redessiné — l'IA a complètement merdé. **Loss weight x3 ou plus**.

Cible : faire baisser le `correction_weight` moyen sur le split val/test à chaque
itération du pipeline.

## Schema des `sections` (roof_model / roof_sections_v16)

- `roof_model.sections[i]` :
  - `pts` : array de `{x, y}` (≥3 points fermés) en pixels image
  - `pitch` : pente en X/12 (7 = 7/12 ratio standard)
  - `roof_type` : "hip" | "gable" | "shed" | …
  - `source` : "human" | "mvp" | "merged"

- `roof_sections_v16.sections[i]` : voir le contrat `sections-1.6.0` dans
  `src/lib/roof-core/adapters/fromRoofSectionsV16.ts`. Champs clés :
  - `points` : array `[x, y]` (≥3 pts) en pixels image
  - `selection_status` : "kept" | "alternative" | "rejected" (**SEULE vérité d'activation**)
  - `role` : "main" | "ridge_candidate"
  - `structural_score`, `ridge_visible_score`, `plane_symmetry_score` : scores 0..1

## Splits déterministes

Le `split` (train/val/test) est calculé par hash FNV-1a 32-bit du `dataset.id` modulo 100 :
- 0-69 → train (70%)
- 70-84 → val (15%)
- 85-99 → test (15%)

→ **Un dataset reste TOUJOURS dans le même split à travers les exports.** Pas de leak entre re-exports.

## Versioning

- `manifest.schema_version` change à chaque modification breaking du layout.
- Si tu construis un loader, **assert sur le schema_version exact** pour éviter
  les surprises silencieuses.

---

Documentation auto-générée par buildBundleReadme dans src/lib/training-lab.ts.
